Para facilitar a execução vai ser enviado em conjunto um arquivo Makefile

As regras são as seguintes
    - make knn -> roda o arquivo de análise do knn
    - make kmenas -> roda o arquivo de análise do kmeans
    - make e_knn -> roda o arquivo extra do knn
    - make e_kmeans -> roda o arquivo extra do kmeans

Os outros apenas contem as funções que são utilizadas nos demais arquivos.
Como não foi especificado, os datasets vão ser enviados em conjunto e é esperado que eles estejam
no mesmo diretório na hora da execução